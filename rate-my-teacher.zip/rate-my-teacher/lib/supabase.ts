// Supabase client setup placeholder
// TODO: initialize supabase client here
export const supabase = null as any;
