// Homepage (Search landing) placeholder
export default function HomePage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>rate-my-teacher</h1>
      <p>Project scaffold created from the folder structure diagram.</p>
    </main>
  );
}
