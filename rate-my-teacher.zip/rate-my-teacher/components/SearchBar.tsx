// Reusable UI: SearchBar placeholder
export function SearchBar() {
  return (
    <div>
      <input placeholder="Search" />
    </div>
  );
}
