// Reusable UI: ProfessorCard placeholder
export function ProfessorCard() {
  return (
    <div>
      <strong>ProfessorCard</strong>
    </div>
  );
}
